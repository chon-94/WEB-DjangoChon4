# PingChecker.1.1
 Hacer PING a sitios web
